document.addEventListener("DOMContentLoaded", () => {
  // Fetch and display bundles
  fetchBundles();

  // Handle cancel button click
  const cancelBtn = document.getElementById("cancel-btn");
  cancelBtn.addEventListener("click", () => {
      document.getElementById("bundle-popup").classList.add("hidden");
  });
});

// Global variables for pagination and search
let currentPage = 1;
let rowsPerPage = 5; // Default number of rows per page
let allBundles = [];
let totalBundles = 0;

// Function to fetch bundles and populate the table
async function fetchBundles() {
  const bundleTbody = document.getElementById("bundle-tbody");
  const tableInfo = document.getElementById("table-info");

  try {
      const response = await fetch('/bundles/list'); // Fetch bundles data
      
      // Check if the response is ok (status in the range 200-299)
      if (!response.ok) {
          const errorData = await response.json();
          throw new Error(errorData.error || 'Failed to fetch bundles');
      }

      const bundles = await response.json();
      allBundles = bundles; // Store all bundles for pagination and search
      totalBundles = bundles.length; // Total number of bundles

      // Clear existing rows in the table
      bundleTbody.innerHTML = '';

      // Display the current page of bundles
      displayBundles();

      // Update table info
      updateTableInfo();

      // Attach event listeners to the eye icons
      attachShowIconListeners(bundles);
  } catch (error) {
      console.error("Error fetching bundles:", error);
      alert("An error occurred while fetching bundles: " + error.message); // Notify the user
  }
}

// Function to display bundles based on the current page and rows per page
function displayBundles() {
  const bundleTbody = document.getElementById("bundle-tbody");
  const start = (currentPage - 1) * rowsPerPage;
  const end = Math.min(start + rowsPerPage, totalBundles);

  // Clear existing rows
  bundleTbody.innerHTML = '';

  for (let i = start; i < end; i++) {
      const bundle = allBundles[i];
      const totalPrice = typeof bundle.total_price === 'number' ? bundle.total_price : parseFloat(bundle.total_price) || 0;

      const row = document.createElement('tr');
      row.innerHTML = `
          <td>${ bundle.bundle_id}</td>
          <td>${bundle.bundle_name}</td>
          <td>₱${totalPrice.toFixed(2)}</td>
          <td>${bundle.discount}%</td>
          <td>${bundle.bundle_status}</td>
          <td>
              <i class='bx bx-show' data-id="${bundle.bundle_id}"></i>
              <a href="/editBundle"><i class='bx bx-edit'></i></a>
          </td>
      `;
      bundleTbody.appendChild(row);
  }

  updateTableInfo(); // Update table info after displaying bundles
}

// Function to update table info based on current pagination
function updateTableInfo() {
  const tableInfo = document.getElementById("table-info");
  const start = (currentPage - 1) * rowsPerPage + 1;
  const end = Math.min(start + rowsPerPage - 1, totalBundles);
  tableInfo.textContent = `Showing ${start} to ${end} of ${totalBundles} Entities`;
}

// Function to handle pagination
function handlePagination() {
  const prevButton = document.querySelector(".pagination-btn:first-child");
  const nextButton = document.querySelector(".pagination-btn:last-child");

  prevButton.addEventListener("click", () => {
      if (currentPage > 1) {
          currentPage--;
          displayBundles();
      }
  });

  nextButton.addEventListener("click", () => {
      if (currentPage * rowsPerPage < totalBundles) {
          currentPage++;
          displayBundles();
      }
  });
}

// Search functionality
document.getElementById("search").addEventListener("input", function () {
  const searchTerm = this.value.toLowerCase();
  
  if (searchTerm) {
      allBundles = allBundles.filter(bundle => 
          bundle.bundle_name.toLowerCase().includes(searchTerm) ||
          bundle.bundle_description.toLowerCase().includes(searchTerm)
      );
  } else {
      fetchBundles(); // Reset to original bundles if search is empty
  }
  totalBundles = allBundles.length; // Update total bundles after search
  currentPage = 1; // Reset to first page
  displayBundles(); // Display filtered bundles
});

// Initialize pagination
handlePagination();

// Function to attach event listeners to the eye icons
function attachShowIconListeners(bundles) {
  const showIcons = document.querySelectorAll(".bx-show");
  showIcons.forEach(icon => {
    icon.addEventListener("click", () => {
      const bundleId = icon.getAttribute("data-id");
      const selectedBundle = bundles.find(b => b.bundle_id == bundleId);
      if (selectedBundle) {
        // Populate the popup with the selected bundle's details
        document.getElementById("popup-bundle-name").textContent = selectedBundle.bundle_name;
        document.getElementById("popup-description").textContent = selectedBundle.bundle_description || "No description available.";

        const totalPrice = parseFloat(selectedBundle.total_price) || 0;
        const discountPrice = totalPrice * (1 - (selectedBundle.discount / 100));

        document.getElementById("popup-price-from").innerHTML = `<span style="text-decoration: line-through;">₱${totalPrice.toFixed(2)}</span>`;
        document.getElementById("popup-price-to").textContent = `₱${discountPrice.toFixed(2)}`;

        const imageUrl = selectedBundle.bundle_image ? `/uploads/${selectedBundle.bundle_image}` : '';
        const popupImgElement = document.getElementById("popup-img");
        popupImgElement.src = imageUrl;

        if (imageUrl) {
          popupImgElement.style.display = 'block';
        } else {
          popupImgElement.style.display = 'none';
        }

        // Add "Includes:" section for product names
        const includesContainer = document.getElementById("includes-products");
        includesContainer.innerHTML = ''; // Clear existing products
        selectedBundle.products.forEach(product => {
          const productItem = document.createElement('li');
          productItem.textContent = product.product_name; // Add product name
          includesContainer.appendChild(productItem);
        });

        const saveBtn = document.getElementById("save-btn");
        saveBtn.onclick = () => {
          const popupContent = document.querySelector(".popup-content"); // The content to be captured
          
          // Hide the elements to exclude
          const includesToggle = document.getElementById("includes-toggle");
          const includesModal = document.getElementById("includes-modal");
          const cancelButton = document.getElementById("cancel-btn");
          
          includesToggle.style.display = "none"; // Hide "Included Products" toggle
          includesModal.style.display = "none"; // Hide "Included Products" modal
          cancelButton.style.display = "none"; // Hide "Cancel" button
          
          // Capture the popup content
          html2canvas(popupContent).then(canvas => {
            // Create a link element to download the image
            const link = document.createElement('a');
            link.href = canvas.toDataURL("image/png"); // Convert canvas to data URL
            link.download = `${document.getElementById("popup-bundle-name").textContent}.png`; // Set the file name
            document.body.appendChild(link); // Append link to the body
            link.click(); // Trigger the download
            document.body.removeChild(link); // Remove the link from the document
          }).finally(() => {
            // Restore the hidden elements
            includesToggle.style.display = "inline"; // Show "Included Products" toggle
            includesModal.style.display = "block"; // Show "Included Products" modal
            cancelButton.style.display = "inline"; // Show "Cancel" button
          });
        };

        // Show includes modal on hover
        const includesToggle = document.getElementById("includes-toggle");
        const includesModal = document.getElementById("includes-modal");

        includesToggle.addEventListener("mouseenter", () => {
          includesModal.classList.remove("hidden");

          // Center the modal relative to the "Includes" text
          const toggleRect = includesToggle.getBoundingClientRect();
          const modalWidth = includesModal.offsetWidth;

          // Calculate the left position to center the modal
          const leftPosition = toggleRect.left + (toggleRect.width / 2) - (modalWidth / 2);
          includesModal.style.left = `${leftPosition}px`;
          
          // Position above the text
          includesModal.style.top = `${toggleRect.top + window.scrollY - includesModal.offsetHeight}px`; // Position above the text
        });

        includesToggle.addEventListener("mouseleave", () => {
          includesModal.classList.add("hidden");
        });

        // Position the modal correctly
        includesModal.style.left = `${includesToggle.getBoundingClientRect().left}px`;
        includesModal.style.top = `${includesToggle.getBoundingClientRect().bottom}px`;

        document.getElementById("bundle-popup").classList.remove("hidden"); // Show the popup
      }
    });
  });
}