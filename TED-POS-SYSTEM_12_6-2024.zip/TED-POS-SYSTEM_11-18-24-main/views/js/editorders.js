let originalProducts = []; // Store the original products for filtering
let originalBundles = []; // Store the original bundles for filtering
let totalOrderAmount = 0; // Keep track of the total order amount

document.addEventListener('DOMContentLoaded', function () {
    fetchProducts(); // Fetch products on load
    fetchBundles(); // Fetch bundles on load
    fetchCategories(); // Fetch categories on load
    const urlParams = new URLSearchParams(window.location.search);
    const orderId = urlParams.get('id');

    if (orderId) {
        fetchOrderDetails(orderId); // Fetch order details if an ID is provided
    }

    // Fetch Order Details
    async function fetchOrderDetails(orderId) {
        const response = await fetch(`/orders/edit/${orderId}`);
        const order = await response.json();
    
        if (!order || !order.OrderItems || order.OrderItems.length === 0) {
            console.error("No order items found in the response.");
            return;
        }
    
        const orderListBody = document.getElementById('order-list-body');
        orderListBody.innerHTML = ''; // Clear existing rows
    
        let totalAmount = 0; // Initialize total amount
    
        order.OrderItems.forEach(item => {
            const productName = item.product_id ? item.Product.product_name : item.Bundle.bundle_name;
            const price = item.price;  // Ensure `item.price` is valid
            const quantity = item.quantity;
    
            if (isNaN(price) || price <= 0) {
                console.error('Invalid price:', price);
                return;
            }
    
            const newRow = document.createElement('tr');
            newRow.innerHTML = ` 
                <td>
                    <div class="quantity-control">
                        <button class="quantity-btn decrement-btn" onclick="decrementQuantityFetch(this)">
                            <i class="bx bx-minus"></i>
                        </button>
                        <input type="number" value="${quantity}" min="1" class="quantity-input" />
                        <button class="quantity-btn increment-btn" onclick="incrementQuantityFetch(this)">
                            <i class="bx bx-plus"></i>
                        </button>
                    </div>
                </td>
                <td>${productName}</td>
                <td class="amount-cell" data-unit-price="${price.toFixed(2)}">
                    ₱${(price * quantity).toFixed(2)}
                </td>
                <td>
                    <button class="delete-btn" onclick="deleteRow(this)">
                        <i class="bx bx-trash"></i>
                    </button>
                </td>
            `;
            
            // Make sure to set the `data-unit-price` attribute for the row
            newRow.setAttribute('data-unit-price', price.toFixed(2));
    
            // Add the new row to the table body
            orderListBody.appendChild(newRow);
    
            // Update total amount
            totalAmount += price * quantity;
        });
    
        // Set the total price
        document.getElementById('total-price').textContent = `₱${totalAmount.toFixed(2)}`;
    
        // Set the amount tendered from the order details
        const amountTendered = order.amount_rendered || 0; // Use the amount_rendered from the order
        document.getElementById('amount-tendered').value = amountTendered;
    
        // Calculate and display the change
        updateChange();
    }


    async function fetchProducts() {
        const response = await fetch('/products/data');
        originalProducts = await response.json(); // Store products
        displayProducts(originalProducts); // Initially display all products
    }    

    async function fetchBundles() {
        const response = await fetch('/bundles/list'); // Update this URL to match your endpoint
        originalBundles = await response.json(); // Store the original bundles
        displayBundles(originalBundles); // Initially display all bundles
    }

    async function fetchCategories() {
        const response = await fetch('/categories/list');
        const categories = await response.json();
        const categorySelect = document.getElementById('category-select');
    
        categories.forEach(category => {
            const option = document.createElement('option');
            option.value = category.category_id;
            option.textContent = category.category_name;
            categorySelect.appendChild(option);
        });
    
        // Initialize Select2 for the dropdown
        $(categorySelect).select2({
            placeholder: "Select a category",
            allowClear: true
        });
    }

    function displayProducts(products) {
        const productGrid = document.getElementById('product-grid');
        productGrid.innerHTML = ''; // Clear existing products

        products.forEach(product => {
            const productPlaceholder = document.createElement('div');
            productPlaceholder.className = 'product-placeholder';
            productPlaceholder.innerHTML = `
                <img src="/uploads/${product.product_img || 'default-image.jpg'}" alt="${product.product_name}" />
                <p>${product.product_name}</p>
                <p class="Model">${product.product_model}</p>
                <p class="available-quantity">Available: ${product.product_quantity}</p>
                <span class="price-tag">₱${product.selling_price}</span>
            `;
            productPlaceholder.addEventListener('click', function () {
                addToOrderList(product.product_name, product.selling_price, product.product_id, false);
            });
            productGrid.appendChild(productPlaceholder);
        });
    }

    function displayBundles(bundles) {
        const productGrid = document.getElementById('product-grid');
        bundles.forEach(bundle => {
            const bundlePlaceholder = document.createElement('div');
            bundlePlaceholder.className = 'product-placeholder';
            bundlePlaceholder.innerHTML = `
                <img src="/uploads/${bundle.bundle_image || 'default-image.jpg'}" alt="${bundle.bundle_name}" />
                <p>${bundle.bundle_name}</p>
                <span class="price-tag">₱${bundle.total_price}</span>
                <span class="show-included" 
                    onmouseenter="showIncludedProducts(event, ${bundle.bundle_id})" 
                    onmouseleave="hideIncludedProducts()">
                    Show Included Products
                </span>
            `;
            bundlePlaceholder.addEventListener('click', function () {
                addToOrderList(bundle.bundle_name, bundle.total_price, bundle.bundle_id, true);
            });
            productGrid.appendChild(bundlePlaceholder);
        });
    }

    // Add to Order List
    function addToOrderList(itemName, itemPrice, itemId, isBundle = false) {
        const orderListBody = document.getElementById('order-list-body');
        const existingRow = Array.from(orderListBody.querySelectorAll('tr')).find(row => {
            const nameCell = row.querySelector('td:nth-child(2)');
            return nameCell.textContent === itemName;
        });
    
        const priceAsNumber = parseFloat(itemPrice);
    
        if (existingRow) {
            const quantityInput = existingRow.querySelector('.quantity-input');
            quantityInput.value = parseInt(quantityInput.value) + 1;
            const priceCell = existingRow.querySelector('.amount-cell');
            const unitPrice = parseFloat(existingRow.getAttribute('data-price'));
            priceCell.textContent = `₱${(unitPrice * quantityInput.value).toFixed(2)}`;
        } else {
            const newRow = document.createElement('tr');
            newRow.innerHTML = `
                <td>
                    <div class="quantity-control">
                        <button class="quantity-btn decrement-btn" onclick="decrementQuantityAdd(this)">
                            <i class="bx bx-minus"></i>
                        </button>
                        <input type="number" value="1" min="1" class="quantity-input" />
                        <button class="quantity-btn increment-btn" onclick="incrementQuantityAdd(this)">
                            <i class="bx bx-plus"></i>
                        </button>
                    </div>
                </td>
                <td>${itemName}</td>
                <td class="amount-cell">₱${priceAsNumber.toFixed(2)}</td>
                <td>
                    <button class="delete-btn" onclick="deleteRow(this)">
                        <i class="bx bx-trash"></i>
                    </button>
                </td>
            `;
            newRow.setAttribute('data-price', priceAsNumber); // Store the unit price
            newRow.setAttribute('data-product-id', isBundle ? `bundle-${itemId}` : `product-${itemId}`);
            orderListBody.appendChild(newRow);
            newRow.classList.add('added-row');
        }
    
        calculateTotalAmount();
    }


    // Increment Quantity Add (in Add to Order List)
    window.incrementQuantityAdd = function (button) {
        const row = button.closest('tr');
        const input = button.previousElementSibling;
        let value = parseInt(input.value);
        value += 1; // Increment the quantity
        input.value = value;
    
        const priceCell = row.querySelector('.amount-cell');
        const unitPrice = parseFloat(row.getAttribute('data-price')); // Fetch the unit price
    
        if (!isNaN(unitPrice)) {
            const newAmount = unitPrice * value;
            priceCell.textContent = `₱${newAmount.toFixed(2)}`;
        } else {
            console.error('Unit price is invalid:', unitPrice);
        }
    
        calculateTotalAmount();
    };

    // Decrement Quantity Add (in Add to Order List)
    window.decrementQuantityAdd = function (button) {
        const row = button.closest('tr');
        const input = button.nextElementSibling;
        let value = parseInt(input.value);
        if (value > 1) {
            value -= 1; // Decrement the quantity
            input.value = value;
    
            const priceCell = row.querySelector('.amount-cell');
            const unitPrice = parseFloat(row.getAttribute('data-price')); // Fetch the unit price
    
            if (!isNaN(unitPrice)) {
                const newAmount = unitPrice * value;
                priceCell.textContent = `₱${newAmount.toFixed(2)}`;
            } else {
                console.error('Unit price is invalid:', unitPrice);
            }
        }
    
        calculateTotalAmount();
    };

    // Increment Quantity Fetch (in Fetch Order Details)
    window.incrementQuantityFetch = function (button) {
        const row = button.closest('tr');
        const input = button.previousElementSibling;
        let value = parseInt(input.value);
        value += 1; // Increment the quantity
        input.value = value;
    
        const priceCell = row.querySelector('.amount-cell');
        const unitPrice = parseFloat(row.getAttribute('data-unit-price')); // Use 'data-unit-price' for fetched data
    
        if (!isNaN(unitPrice)) {
            const newAmount = unitPrice * value;
            priceCell.textContent = `₱${newAmount.toFixed(2)}`;
        } else {
            console.error('Unit price is invalid:', unitPrice);
        }
    
        calculateTotalAmount();
    };

    // Decrement Quantity Fetch (in Fetch Order Details)
    window.decrementQuantityFetch = function (button) {
        const row = button.closest('tr');
        const input = button.nextElementSibling;
        let value = parseInt(input.value);
        if (value > 1) {
            value -= 1; // Decrement the quantity
            input.value = value;
    
            const priceCell = row.querySelector('.amount-cell');
            const unitPrice = parseFloat(row.getAttribute('data-unit-price')); // Use 'data-unit-price' for fetched data
    
            if (!isNaN(unitPrice)) {
                const newAmount = unitPrice * value;
                priceCell.textContent = `₱${newAmount.toFixed(2)}`;
            } else {
                console.error('Unit price is invalid:', unitPrice);
            }
        }
    
        calculateTotalAmount();
    };
    
    // Calculate Total Amount
    function calculateTotalAmount() {
        const orderListBody = document.getElementById('order-list-body');
        const rows = orderListBody.querySelectorAll('tr');
        let totalAmount = 0;
    
        rows.forEach(row => {
            const priceCell = row.querySelector('.amount-cell');
            const amount = parseFloat(priceCell.textContent.replace('₱', '').replace(',', ''));
            if (!isNaN(amount)) {
                totalAmount += amount;
            }
        });
    
        document.getElementById('total-price').textContent = `₱${totalAmount.toFixed(2)}`;
        updateChange();
    }

    // Delete Row
    window.deleteRow = function (button) {
        const row = button.closest('tr');
        row.remove();
        calculateTotalAmount();
    };

    // Function to update the change dynamically
    function updateChange() {
        const totalPriceText = document.getElementById('total-price').textContent.replace('₱', '').replace(',', '');
        const totalPrice = parseFloat(totalPriceText) || 0;
    
        const amountTenderedInput = parseFloat(document.getElementById('amount-tendered').value) || 0;
        const changeField = document.getElementById('change');
    
        if (amountTenderedInput < totalPrice) {
            changeField.value = 'Insufficient amount'; // Show warning if tendered amount is less than total
        } else {
            const change = amountTenderedInput - totalPrice; // Calculate change
            changeField.value = `₱${change.toFixed(2).toLocaleString()}`; // Format the change
        }
    }

    document.getElementById('product-search').addEventListener('input', function () {
        const searchTerm = this.value.toLowerCase();
        filterProducts(searchTerm);
    });

    $('#category-select').on('change', function() {
        const selectedCategory = $(this).val();
        const searchTerm = document.getElementById('product-search').value.toLowerCase();
        filterProducts(searchTerm, selectedCategory);
    });

    function filterProducts(searchTerm, selectedCategory = 'all') {
        let filteredProducts = originalProducts;  // Assuming originalProducts is a list of all products

        // Apply search term filter
        if (searchTerm) {
            filteredProducts = filteredProducts.filter(product =>
                product.product_name.toLowerCase().includes(searchTerm) ||
                product.product_model.toLowerCase().includes(searchTerm)
            );
        }

        // Apply category filter
        if (selectedCategory && selectedCategory !== 'all') {
            filteredProducts = filteredProducts.filter(product => product.category_id == selectedCategory);
        }

        // Clear the product grid first
        document.getElementById('product-grid').innerHTML = '';

        // Display filtered products
        displayProducts(filteredProducts);  // Make sure this function correctly displays the filtered products

        // Handle bundles (only show them when 'all' is selected)
        if (selectedCategory === 'all') {
            displayBundles(originalBundles);  // Assuming displayBundles is a function to show bundles
        } else {
            // Hide bundles if a specific category is selected
            document.getElementById('bundle-grid').innerHTML = '';  // Clear the bundle grid
        }
    }

    window.showIncludedProducts = function (event, bundleId) {
        const bundle = originalBundles.find(b => b.bundle_id === bundleId);
        if (!bundle || !bundle.products) return;

        const modal = document.getElementById('included-products-modal');
        const productList = document.getElementById('included-products-list');

        // Clear previous modal content
        productList.innerHTML = '';

        // Populate the modal with bundle products
        bundle.products.forEach(product => {
            const li = document.createElement('li');
            li.textContent = product.product_name;
            productList.appendChild(li);
        });

        // Get bounding rectangle of the hovered element
        const rect = event.target.closest('.product-placeholder').getBoundingClientRect();

        // Adjust position to center horizontally and place above the bundle image
        modal.style.top = `${rect.top - modal.offsetHeight}px`; // Place above the bundle
        modal.style.left = `${rect.left + rect.width / 2 - modal.offsetWidth / 2}px`; // Center horizontally
        modal.style.display = 'block'; // Make the modal visible
    };

    let hideTimeout; // Variable to track the hide timeout

    window.hideIncludedProducts = function () {
        // Add a slight delay before hiding the modal
        hideTimeout = setTimeout(() => {
            const modal = document.getElementById('included-products-modal');
            modal.style.display = 'none';
        }, 200); // 200ms delay to prevent flickering
    };

    // Cancel the hiding timeout when re-entering the modal
    document.getElementById('included-products-modal').addEventListener('mouseenter', function () {
        clearTimeout(hideTimeout);
    });

    // Hide the modal when leaving it
    document.getElementById('included-products-modal').addEventListener('mouseleave', function () {
        const modal = document.getElementById('included-products-modal');
        modal.style.display = 'none';
    });

    document.getElementById('amount-tendered').addEventListener('input', function () {
        const amountTenderedInput = parseFloat(this.value) || 0; // Get the input value or default to 0
        const totalPriceText = document.getElementById('total-price').textContent.replace('₱', '').replace(',', '');
        const totalPrice = parseFloat(totalPriceText) || 0; // Convert total price to a number

        const changeField = document.getElementById('change'); // Get the change field

        if (amountTenderedInput < totalPrice) {
            changeField.value = 'Insufficient amount'; // Show warning if tendered amount is less than total
        } else {
            const change = amountTenderedInput - totalPrice; // Calculate change
            // Format the change with commas
            changeField.value = `₱${change.toFixed(2).toLocaleString()}`;
        }
    });

    // Update the pay button functionality
    document.getElementById('update-button').addEventListener('click', async function () {
        const rows = document.querySelectorAll('#order-list-body tr');

        if (rows.length === 0) {
            alert('You must select a product first.'); // Show alert if no products are selected
            return; // Exit the function to prevent further execution
        }
        
        let productIds = [];
        let bundleIds = [];
        let totalAmount = 0;
        let totalQuantity = 0;
        let orderDetails = [];
        let existingOrderItems = []; // To track existing order items for deletion

        // Collect data from the order list
        rows.forEach(row => {
            const productId = row.getAttribute('data-product-id'); // Get the product ID
            const quantityInput = row.querySelector('.quantity-input');
            const priceCell = row.querySelector('td:nth-child(3)');
            const price = parseFloat(priceCell.textContent.replace('₱', '').replace(',', ''));
            const quantity = parseInt(quantityInput.value);
            const itemName = row.querySelector('td:nth-child(2)').textContent; // Get the item name

            if (productId) {
                if (productId.startsWith('bundle-')) {
                    bundleIds.push(productId.replace('bundle-', ''));
                    orderDetails.push({
                        bundle_id: productId.replace('bundle-', ''),
                        quantity: quantity,
                        price: price,
                    });
                } else if (productId.startsWith('product-')) {
                    productIds.push(productId.replace('product-', ''));
                    orderDetails.push({
                        product_id: productId.replace('product-', ''),
                        quantity: quantity,
                        price: price,
                    });
                }
            }

            totalAmount += price * quantity;
            totalQuantity += quantity;
        });

        const amountTendered = parseFloat(document.getElementById('amount-tendered').value) || 0;

        // Fetch existing order items to determine which ones to delete
        const orderId = new URLSearchParams(window.location.search).get('id');
        const existingItemsResponse = await fetch(`/orders/${orderId}`);
        const existingOrder = await existingItemsResponse.json();
        existingOrderItems = existingOrder.OrderItems.map(item => ({
            id: item.order_items_id,
            product_id: item.product_id,
            bundle_id: item.bundle_id,
        }));

        // Determine which items to delete
        const itemsToDelete = existingOrderItems.filter(existingItem => {
            const isInCurrentOrder = orderDetails.some(detail => 
                (detail.product_id && detail.product_id == existingItem.product_id) || 
                (detail.bundle_id && detail.bundle_id == existingItem.bundle_id)
            );
            return !isInCurrentOrder; // Keep items that are not in the current order
        });

        // Start updating the order
        try {
            // Update the order summary
            const orderUpdateResponse = await fetch(`/orders/${orderId}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    selectedProducts: productIds,
                    selectedBundles: bundleIds,
                    amountRendered: amountTendered,
                    price: totalAmount,
                    totalQuantity: totalQuantity,
                    orderDetails: orderDetails,
                })
            });

            if (!orderUpdateResponse.ok) {
                const error = await orderUpdateResponse.json();
                alert(`Error updating order: ${error.error}`);
                return;
            }

            // Delete items that are no longer in the order
            for (const item of itemsToDelete) {
                await fetch(`/orderitems/${item.id}`, {
                    method: 'DELETE',
                });
            }

            // Notify the user
            alert('Order updated successfully.');
            resetForm(); // Reset the form

            // Refresh products and bundles to reflect updated quantities
            await fetchProducts();
            await fetchBundles();
        } catch (error) {
            console.error("Error updating order:", error);
            alert("An error occurred while updating your order.");
        }
    });

    function resetForm() {
        // Clear the order list
        document.getElementById('order-list-body').innerHTML = '';

        // Reset the total price, amount tendered, and change fields
        document.getElementById('total-price').textContent = '₱0.00'; // Reset the total price display
        document.getElementById('amount-tendered').value = ''; // Clear amount tendered input
        document.getElementById('change').value = ''; // Clear change field

        // Reset the search input
        document.getElementById('product-search').value = ''; // Reset product search input
        // Optionally clear the category selection
        $('#category-select').val(null).trigger('change'); // Reset category select2 dropdown
    }

    // Add an event listener for the cancel button
    document.querySelector('#cancel_daw').addEventListener('click', function () {
        resetForm(); // Reset the form without affecting the product and bundle display
    });
}); 