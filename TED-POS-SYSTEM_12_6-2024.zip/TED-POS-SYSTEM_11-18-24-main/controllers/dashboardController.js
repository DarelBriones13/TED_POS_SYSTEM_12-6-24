// controllers/dashboardController.js
const db = require('../models');

exports.getDashboardData = async (req, res) => {
  
  try {
    const categoriesCount = await db.Category.count();
    console.log('Categories Count:', categoriesCount); // Debugging line
    
    const productsCount = await db.products.count();
    console.log('Products Count:', productsCount); // Debugging line
    
    const suppliersCount = await db.Supplier.count();
    console.log('Suppliers Count:', suppliersCount); // Debugging line
    
    const bundlesCount = await db.Bundles.count();
    console.log('Bundles Count:', bundlesCount); // Debugging line
    
    const usersCount = await db.User.count();
    console.log('Users Count:', usersCount); // Debugging line
    
    const totalOrdersCount = await db.Order.count();
    console.log('Total Orders Count:', totalOrdersCount); // Debugging line

    // Calculate today's sales
    const today = new Date();
    const startOfDay = new Date(today.setHours(0, 0, 0, 0));
    const endOfDay = new Date(today.setHours(23, 59, 59, 999));

    const todaysSales = await db.Order.sum('total_amount', {
      where: {
        date_created: {
          [db.Sequelize.Op.between]: [startOfDay, endOfDay]
        }
      }
    });
    console.log('Today\'s Sales:', todaysSales); // Debugging line

    // Calculate total sales
    const totalSales = await db.Order.sum('total_amount');
    console.log('Total Sales:', totalSales); // Debugging line

    res.json({
      categoriesCount,
      productsCount,
      suppliersCount,
      bundlesCount,
      usersCount,
      totalOrdersCount,
      todaysSales,
      totalSales
    });
  } catch (error) {
    console.error("Error fetching dashboard data:", error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

const { Op, Sequelize } = require('sequelize');

exports.getDailySalesData = async (req, res) => {
    try {
        const today = new Date();
        const last7Days = new Date(today.getFullYear(), today.getMonth(), today.getDate() - 6);

        // Fetch data from orders table for the last 7 days
        const salesData = await db.Order.findAll({
            where: {
                date_created: {
                    [Op.between]: [last7Days, today]
                }
            },
            attributes: [
                [Sequelize.fn('DATE', Sequelize.col('date_created')), 'date'], // Group by day
                [Sequelize.fn('SUM', Sequelize.col('total_amount')), 'total_sales']
            ],
            group: ['date'],
            order: [['date', 'ASC']]
        });

        // Format the data to fill in missing dates (default to 0 for missing days)
        const formattedData = [];
        const datesSet = new Set(salesData.map(item => item.dataValues.date)); // Dates with sales
        for (let i = 6; i >= 0; i--) {
            const day = new Date(today.getFullYear(), today.getMonth(), today.getDate() - i);
            const formattedDay = day.toISOString().split('T')[0]; // Format as yyyy-mm-dd
            formattedData.push({
                date: formattedDay,
                total_sales: datesSet.has(formattedDay)
                    ? parseFloat(salesData.find(item => item.dataValues.date === formattedDay).dataValues.total_sales)
                    : 0
            });
        }

        res.json(formattedData);
    } catch (error) {
        console.error("Error fetching daily sales data:", error);
        res.status(500).json({ error: "Internal server error" });
    }
};
