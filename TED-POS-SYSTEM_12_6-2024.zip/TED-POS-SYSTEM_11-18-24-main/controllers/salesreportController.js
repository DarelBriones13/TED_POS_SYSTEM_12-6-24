const db = require('../models');

const getSalesReport = async (startDate, endDate) => {
  try {
    // If both startDate and endDate are provided, we will convert them to Date objects.
    // Start of the start date (00:00:00) and end of the end date (23:59:59)
    if (startDate && endDate) {
      const start = new Date(startDate);
      const end = new Date(endDate);
      
      // Set the time for start date to 00:00:00
      start.setHours(0, 0, 0, 0);

      // Set the time for end date to 23:59:59
      end.setHours(23, 59, 59, 999);

      // Use Sequelize's Op.between for filtering the date range
      const orders = await db.Order.findAll({
        where: {
          date_created: {
            [db.Sequelize.Op.between]: [start, end]  // Filtering the date_created field between start and end
          }
        },
        attributes: ['date_created', 'ref_num', 'or_num', 'total_items', 'total_amount']
      });

      return orders.map(order => ({
        date_created: order.date_created.toISOString(),
        ref_num: order.ref_num,
        or_num: order.or_num,
        total_items: order.total_items,  // Directly use total_items from the orders table
        total_amount: order.total_amount,
      }));
    }

    // If no date range is selected, return all orders
    const orders = await db.Order.findAll({
      attributes: ['date_created', 'ref_num', 'or_num', 'total_items', 'total_amount']
    });

    return orders.map(order => ({
      date_created: order.date_created.toISOString(),
      ref_num: order.ref_num,
      or_num: order.or_num,
      total_items: order.total_items,
      total_amount: order.total_amount,
    }));
    
  } catch (error) {
    console.error("Error fetching sales report:", error);
    throw error;
  }
};

module.exports = {
  getSalesReport
};
