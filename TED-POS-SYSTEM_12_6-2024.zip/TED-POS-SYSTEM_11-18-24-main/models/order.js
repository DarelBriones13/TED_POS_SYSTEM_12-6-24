module.exports = (sequelize, DataTypes) => {
  const Order = sequelize.define('Order', {
      orders_id: {
          type: DataTypes.INTEGER,
          primaryKey: true,
          autoIncrement: true,
      },
      ref_num: DataTypes.STRING,
      or_num: DataTypes.STRING,
      total_amount: DataTypes.FLOAT,
      amount_rendered: DataTypes.FLOAT,
      change_amount : DataTypes.FLOAT,
      total_items: DataTypes.INTEGER,
      date_created: DataTypes.DATE,
      user_id: DataTypes.INTEGER,
  }, {});

  Order.associate = (models) => {
    Order.hasMany(models.OrderItem, { foreignKey: 'orders_id' });
    Order.belongsTo(models.User, { foreignKey: 'user_id' }); // Correctly reference user_id
};

  return Order;
};