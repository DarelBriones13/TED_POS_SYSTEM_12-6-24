'use strict';
const { Model } = require('sequelize');

module.exports = (sequelize, DataTypes) => {
  class Bundles extends Model {
    static associate(models) {
      // Define associations
      Bundles.belongsToMany(models.products, {
        through: 'BundleProducts', // Assuming a join table
        foreignKey: 'bundle_id',
        otherKey: 'product_id',
        as: 'products' // Alias for the association
      });
    }
  }

  Bundles.init({
    bundle_id: {
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true,
      autoIncrement: true
    },
    bundle_name: {
      type: DataTypes.STRING,
      allowNull: false
    },
    bundle_image: {
      type: DataTypes.STRING,
      allowNull: true
    },
    bundle_description: {
      type: DataTypes.STRING,
      allowNull: true
    },
    total_price: {
      type: DataTypes.DECIMAL,
      allowNull: false
    },
    discount: {
      type: DataTypes.DECIMAL,
      allowNull: true
    },
    product_ids: {
      type: DataTypes.JSON, // Allows storing an array of product IDs
      allowNull: false
    },
    bundle_status: {
      type: DataTypes.STRING,
      allowNull: true
    }
  }, {
    sequelize,
    modelName: 'Bundles',
  });

  return Bundles;
};