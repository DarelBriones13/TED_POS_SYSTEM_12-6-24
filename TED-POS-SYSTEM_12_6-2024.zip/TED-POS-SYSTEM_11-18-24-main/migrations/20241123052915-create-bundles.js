'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('Bundles', {
      bundle_id: { // Change 'id' to 'bundle_id' for consistency
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      bundle_name: {
        type: Sequelize.STRING,
        allowNull: false
      },
      bundle_image: {
        type: Sequelize.STRING,
        allowNull: true
      },
      bundle_description: {
        type: Sequelize.STRING,
        allowNull: true
      },
      total_price: {
        type: Sequelize.DECIMAL,
        allowNull: false
      },
      discount: {
        type: Sequelize.DECIMAL,
        allowNull: true
      },
      bundle_status: {
        type: Sequelize.STRING,
        allowNull: true
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable('Bundles');
  }
};